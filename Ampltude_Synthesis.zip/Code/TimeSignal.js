var song;
var button;
var amp;
var v;
var real_v;
var wave = [];
var slider;
var img;

function preload()
{
	img = loadImage("1.jpeg");
}
function setup()
{
	
	createCanvas(600,600);
	song = loadSound("A.mp3",loading);
	amp = new p5.Amplitude();
	slider = createSlider(0,2,1,0.01);
	

}

function loading()
{
	console.log("loaded");
	button = createButton("PLAY")
	button.mousePressed(playing);
	
}

function playing()
{
	if(!song.isPlaying())
	{
		song.play();
		button.html("PAUSE");
		
	}
	else 
	{
		song.pause();
		button.html("PLAY");
	}
}

function draw()
{
	
	background(0);
	image(img,175,320);

	textSize(50);
	fill(255);
	text('NIRVANA',185,50);
	v = amp.getLevel();
	a = v *1000;

	song.setVolume(slider.value());
	//song.rate(slider.value());

	wave.unshift(-a)
	translate(100,250);

	beginShape();
	for(let i =0;i<wave.length;i++)
	{
		stroke(255,0,200);
		noFill();
		vertex(i/2,wave[i]);
	}
	endShape();
}